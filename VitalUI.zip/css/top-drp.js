var ver='3.0.1D'
var m1=new Object
m1.name='m1'
m1.fnm=''
if(!window.lastm||window.lastm<1)lastm=1
m1.v17=null
m1.v17Timeout=''
var maxZ=1000
m1.v18
m1.targetFrame
var docLoaded=false
m1.bIncBorder=true
m1.v29=null
m1.v29Str=''
m1.v55=50
m1.scrollStep=10
m1.fadingSteps=2
m1.itemOverDelay=0
m1.transTLO=0
m1.fixSB=0
m1.v21="."
m1.maxlev=2
m1.v22=0
m1.sepH=10
m1.bHlNL=1
m1.showA=1
m1.bVarWidth=0
m1.bShowDel=50
m1.scrDel=0
m1.v23=230
m1.levelOffset=-1
m1.levelOffsety=2
m1.bord=1
m1.vertSpace=3
m1.sep=1
m1.v19=false
m1.bkv=0
m1.rev=0
m1.shs=0
m1.xOff=0
m1.yOff=0
m1.v20=false
m1.cntFrame=""
m1.menuFrame=""
m1.v24=""
m1.mout=true
m1.iconSize=8
m1.closeDelay=1000
m1.tlmOrigBg="#ffffff" //first frame mouseout color//
m1.tlmOrigCol="#BF3F0F"
m1.v25=false
m1.v52=false
m1.v60=0
m1.v11=false
m1.v10=0
m1.ppLeftPad=2
m1.v54=0
m1.v01=2
m1.tlmHlBg="#003366" //first frame mouseover color//
m1.tlmHlCol="White"
m1.borderCol="#F9ECF1"
m1.menuHorizontal=true
m1.scrollHeight=6

m1.attr=new Array("12px",false,false,"#ffffff","#209c8d","#ffffff","arial,verdana","#990000","#fff","#fff")

m1mn2=new Array
(
"Nutritional Supplements","nutritional-supplements.html",0,"","",
"Oncology Medicines","oncology-medicines.html",0,"","",
"Antibiotics","antibiotics.html",0,"","",
"UTI Drugs","uti-drugs.html",0,"","",
"Analgesic & Antipyretic Drugs","analgesic-antipyretic-drugs.html",0,"","",
"Male Health Problem Drugs","male-health-problem-drugs.html",0,"","",
"Cardiovascular Drugs","cardiovascular-drugs.html",0,"","",
"Antimalarial Medicines","antimalarial-medicines.html",0,"","",
"Antitubercular Drugs","antitubercular-drugs.html",0,"","",
"Gastrointestinal Drugs","gastrointestinal-drugs.html",0,"","",
"Antiviral Medicines","antiviral-medicines.html",0,"","",
"Anthelmintics Drugs","anthelmintics-drugs.html",0,"","",
"Antiasthmatic Medicines","antiasthmatic-medicines.html",0,"","",
"Antiepileptic Medicines","antiepileptic-medicines.html",0,"","",
"Antifungal Drugs","antifungal-drugs.html",0,"","",
"Antihistaminic Drugs","antihistaminic-drugs.html",0,"","",
"Antiplatelets Drugs","antiplatelets-drugs.html",0,"","",
"Antirheumatic Medicines","antirheumatic-medicines.html",0,"","",
"Corticosteroid and Dermatological Drugs","corticosteroid-dermatological-drugs.html",0,"","",
"Hypoglycemic or Antidiabetic Drugs","hypoglycemic-antidiabetic-drugs.html",0,"","",
"Hypolipidemic Drugs","hypolipidemic-drugs.html",0,"","",
"Immunosuppressants","immunosuppressants.html",0,"",""
)


m1mn3=new Array
(
"Herbal Medicines","herbal-medicines.html",0,"","",
"Male & Female Enhancers","enhancers.html",0,"","",
"Herbal Beauty Products","herbal-beauty-products.html",0,"","",
"Male Health Medicine","male-health-medicine.html",0,"","",
"Female Health Medicine","female-health-medicine.html",0,"",""


)


m1mn4=new Array
(
"Aquaculture Products","aquaculture-products.html",1,"","",
"Poultry Products","poultry-products.html",2,"","",
"Dairy / Large Animal Products","dairy-small-and-large-animals.html",3,"",""
)

m1mn4_1=new Array
(
"Optilite AQ - Aqua Mineral Zeolite","aquaculture-products.html#optilite-aq",0,"","",
"Optilite PRO - Mineral Zeolites with Probiotic","aquaculture-products.html#optilite-pro",0,"","",
"Opticom Plus - Probiotics with Minerals & Amino Acids","aquaculture-products.html#opticome-plus",0,"","",
"Oxynex O<SUB>2</SUB> -  Oxygen Booster","aquaculture-products.html#oxynex-o2",0,"","",
"Biotox Forte - Probiotics 2","aquaculture-products.html#biotox-forte",0,"","",
"Biocom Plus - Probiotics 1","aquaculture-products.html#biocome-plus",0,"","",
"D Germs VXL BKC - Pond Water Sanitizer","aquaculture-products.html#d-germs-vxl-bkc",0,"","",
"Trip XL DS - Triple Salt Sanitizer","aquaculture-products.html#tripxl-ds",0,"","",
"Dynablend Forte -  Enzyme with Probiotics & Yucca","aquaculture-products.html#dynablend-forte",0,"","",
"Rhodocom Plus - Multi Strain Probiotic","aquaculture-products.html#rhodocom-plus",0,"",""
)

m1mn4_2=new Array
(
"Ovigrow XL - Egg Production Enhancer","poultry-products.html#ovigrow-xl",0,"","",
"Diaphos MX - Calcium Supplement","poultry-products.html#diaphos-mx",0,"","",
"Tone UP - Poultry Electrolyte","poultry-products.html#toneup",0,"","",
"Vtox Forte - Toxin Binder","poultry-products.html#vtox-forte",0,"","",
"Vtone XL - Water Soluble Vitamin Supplements","poultry-products.html#vtone-xl",0,"","",
"Hista VET LFS - Supplement for Respiratory Disorder","poultry-products.html#histavet-lfs",0,"","",
"Urocate VET - For Gout & Related Disorder","poultry-products.html#urocate-vet",0,"","",
"Urocat PFS - Anti Gout Herbal Supplement","poultry-products.html#urocat-pfs",0,"","",
"VTA Laymix - Vitamin Premix for Commercial Layers","poultry-products.html#vta-laymix",0,"","",
"Mixsol B5 - Amino Acids wth Choline Chloride & B Complex","poultry-products.html#mixsol-b5",0,"","",
"Rescoral XL - Levofloxacin with Colistin Supplement","poultry-products.html#rescoral-xl",0,"","",

"Vetpunch - Amino Acids with Trace Minerals Tonic","poultry-products1.html#vetpunch",0,"","",
"Amitone XL - Supplement for Anemia","poultry-products1.html#amitone-xl",0,"","",
"Optitone XL - Poultry Energizer","poultry-products1.html#optitone-xl",0,"","",
"CTM XL - Chelated Trace Mineral Premixes","poultry-products1.html#ctm-xl",0,"","",
"Total Feed Broiler Premixes","poultry-products1.html#total-feed-broiler-premix",0,"","",
"Total Feed Layers Premixes","poultry-products1.html#total-feed-layers-premixes",0,"","",
"Hepasyn PFS - Herbal Liver Tonic","poultry-products1.html#hepasyn-pfs",0,"","",
"Hepasyn VET - Liver Tonic","poultry-products1.html#hepasyn-vet",0,"","",
"CBT XL - Enzymes with Probiotics","poultry-products1.html#cbt-xl",0,"","",
"Phyto XL - Phytase Enzymes","poultry-products1.html#phyto-xl",0,"",""

)

m1mn4_3=new Array
(
"CalV XL - Liquid Calcium Supplement","dairy-small-and-large-animals.html#calv-xl",0,"","",
"Amitone XL - Supplement for Anemia","poultry-products1.html#amitone-xl",0,"","",
"Hepasyn PFS - Herbal Liver Tonic","poultry-products1.html#hepasyn-pfs",0,"","",
"Hepasyn VET - Liver Tonic","poultry-products1.html#hepasyn-vet",0,"","",
"Hista VET LFS - Supplement for Respiratory Disorder","poultry-products.html#histavet-lfs",0,"","",
"Rescoral XL - Levofloxacin with Colistin Supplement","poultry-products.html#rescoral-xl",0,"",""

)


m1mn5=new Array
(
"Hand Sanitizer","hand-sanitizer.html",0,"","",
"Hand &amp; Body Wash","hand-body-wash.html",0,"","",
"Disposable Vaginal Douche","disposable-vaginal-douche.html",0,"","",
"D Germs Toilet Seat Sanitizer","d-germs-toilet-seat-sanitizer.html",0,"","",
"D Germs V Wash","d-germs-toilet-seat-sanitizer.html#d-germs-v-wash",0,"",""
)



absPath=""
if(m1.v19&&!m1.v20){
if(window.location.href.lastIndexOf("\\")>window.location.href.lastIndexOf("/")) {sepCh = "\\" ;} else {sepCh = "/" ;}
absPath=window.location.href.substring(0,window.location.href.lastIndexOf(sepCh)+1)}
m1.v61=0
m1.v02=m1.v23
document.write("<style type='text/css'>\n.m1CL0,.m1CL0:link{text-decoration:none;width:100%;color:white; }\n.m1CL0:visited{color:Black}\n.m1CL0:hover{text-decoration:underline}\n.m1mit{padding-left:15px;padding-right:15px;color:Black; font-family:verdana,Arial,Helvetica; font-size:10px; }\n"+"</"+"style>")
document.write("<script language='JavaScript1.2' src='menu-drp.js'></"+"script>")
