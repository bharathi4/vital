﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //lblCount.Text = Application["NoOfVisitors"].ToString();

        //lblSiteVisited.Text = "No of Visitors :" + Application["SiteVisitedCounter"].ToString();
        //lblOnlineUsers.Text = "No of users online on the site=" + Application["OnlineUserCounter"].ToString();
    }
}
