﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class contact_us : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


    }
    public class contactus
    {
        public string Name { get; set; }
        public string EmailId { get; set; }
        public string subject { get; set; }

        public string Message { get; set; }
    }

    [WebMethod]
    public static int Savecontacts(string Name,string EmailId,string subject,string Message)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["ConnString"].ToString());
        SqlCommand cmd = new SqlCommand("insert into contactus (Name ,EmailId,subject,Message) values(@Name ,@EmailId,@subject,@Message)", con);
        cmd.Connection = con;
        con.Open();
        cmd.Parameters.AddWithValue("@Name", Name);
        cmd.Parameters.AddWithValue("@EmailId", EmailId);
        cmd.Parameters.AddWithValue("@subject", subject);
        cmd.Parameters.AddWithValue("@Message", Message);
        
        int i = cmd.ExecuteNonQuery();
        con.Close();
        return i;

    }


}