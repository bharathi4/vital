﻿$(document).ready(function () {
    //$(function () {
    $('#btnsave').click(function () {
        var Name = $('#txtname').val();
        var EmaiId = $('#txtemail').val();
        var Subject = $('#txtsub').val();
        var Message = $('#txtmsg').val();
        if (Name != '' && EmaiId != '' && Subject != '' && Message != '') {
            $.ajax({
                type: "POST",
                url: "contact-us.aspx/Savecontacts",
                data: '{Name:' + JSON.stringify(Name) + ',EmaiId:' + JSON.stringify(EmaiId) + ',Subject:' + JSON.stringify(Subject) + ',Message:' + JSON.stringify(Message) + '}',
                contentType: "application/json; charset=uft-8",
                dataType: "json",

                success: function (response) {
                    $('#txtname').val('');
                    $('#txtemail').val('');
                    $('#txtsub').val('');
                    $('#txtmsg').val('');
                    $('#lblmsg').html('<font color="Green">Records Added Successfully</font>');
                },
                error: function (response) {
                    alert(response.status + ' ' + response.statusText);
                },

            });
        }
    });
});